from __future__ import unicode_literals

from django.apps import AppConfig


class RandomGeneratorConfig(AppConfig):
    name = 'random_generator'
