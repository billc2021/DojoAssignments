from __future__ import unicode_literals

from django.apps import AppConfig


class EmailAppConfig(AppConfig):
    name = 'email_app'
