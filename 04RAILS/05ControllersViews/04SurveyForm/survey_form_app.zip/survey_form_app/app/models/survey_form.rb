class SurveyForm < ApplicationRecord
end
