require 'test_helper'

class DojoTimeTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
