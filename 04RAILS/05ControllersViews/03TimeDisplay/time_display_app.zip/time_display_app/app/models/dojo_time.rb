class DojoTime < ApplicationRecord
end
