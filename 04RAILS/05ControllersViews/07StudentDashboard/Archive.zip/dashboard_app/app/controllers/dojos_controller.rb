class DojosController < ApplicationController
  def index
    @dojos = Dojo.all
  end
  
  def new
  end

  def show
    @dojo = Dojo.find(params[:id])
  end

  def create
    if @dojo = Dojo.create(dojo_params)
      redirect_to :root, notice: "Dojo Successfully Created"
    else
      flash[:errors] = @dojo.errors.full_messages
      redirect_to :back
    end
  end

  def edit
    @dojo = Dojo.find(params[:id])
  end

  def update
    @dojo = Dojo.find(params[:id])
    if @dojo.update(dojo_params)
      redirect_to :root, notice: "Dojo Successfully Updated"
    else 
      flash[:errors] = @dojo.errors.full_messages
      redirect_to :back
    end
  end

  def delete
    dojo = Dojo.find(params[:id])
    dojo.destroy
    redirect_to :root
  end

  private
    def dojo_params
      params.require(:dojo).permit(:branch, :street, :city, :state)
    end
end
