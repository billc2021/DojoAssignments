class Student < ApplicationRecord
  belongs_to :dojo
end
