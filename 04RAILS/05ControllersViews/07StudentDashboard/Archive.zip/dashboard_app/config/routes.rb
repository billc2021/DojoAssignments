Rails.application.routes.draw do
  root 'dojos#index'

  get 'dojos/index'

  get 'dojos/:id/show' => 'dojos#show'

  get 'dojos/new' => 'dojos#new'

  post 'dojos/create' => 'dojos#create'

  get 'dojos/:id/edit' => 'dojos#edit'

  post 'dojos/:id/update' => 'dojos#update'

  get 'dojos/:id/delete' => 'dojos#delete'

  get 'dojos/:dojo_id/students' => 'students#index'

  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
