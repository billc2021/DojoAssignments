class Post < ApplicationRecord
  belongs_to :blog
end
