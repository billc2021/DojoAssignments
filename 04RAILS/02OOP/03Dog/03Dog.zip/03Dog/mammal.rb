class Mammal

	def initialize
		@health = 150
	end

	def display_health
		@health
	end
	
end