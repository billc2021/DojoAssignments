$(document).ready(function(){
    $('#players').hide();
    $('button').click(function(){
        var arenaName = $(this).text();
        // console.log(arenaName);
        var imageLocation = "url('imgs/" + arenaName + ".jpg')";
        // console.log(imageLocation);
        $('#wrapper').css('background-image', imageLocation);
        $('#wrapper').css('background-size', 'cover');
        $('#arenaBtns').css('visibility', 'hidden');
        $('#players').show();
    });
    $(document).on('change', '#leftPlayer', function(){
        var player = ( $(this).find("option:selected").attr('value') );
        var playerImage = "imgs/" + player + ".png";
        $('#playerLeftIMG').attr("src", playerImage);
        }
    )
    $(document).on('change', '#rightPlayer', function(){
        var player = ( $(this).find("option:selected").attr('value') );
        var playerImage = "imgs/" + player + ".png";
        $('#playerRightIMG').attr("src", playerImage);
        }
    )
});