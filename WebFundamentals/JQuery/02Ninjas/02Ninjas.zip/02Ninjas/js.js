<script>
    $('#ninja img')
</script>