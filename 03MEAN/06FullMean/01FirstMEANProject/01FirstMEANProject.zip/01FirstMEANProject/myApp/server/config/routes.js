// var mongoose = require('mongoose');
// var Mongoose = mongoose.model('Mongoose');

// var mongooses = require('../controllers/mongoose.js')
console.log('future routes')

module.exports = function(app){

}