mongoose = require('mongoose')
Friend = mongoose.model('Friend')
friends = require('../controllers/controller')

module.exports = function(app){
    // INDEX
    app.get('/', function(req, res){
        console.log('Root route was hit')
        res.send('Root Rute')
        // friends.index(req, res)
    })

    // CREATE
    app.get('/create', function(req, res){
        console.log('Create/GET route was hit')
        res.send('Create/GET route')
        // friends.create(req, res)
    })

    app.put('/create', function(req, res){
        console.log('Create/PUT route was hit')
        res.send('Create/PUT route')
        // friends.create(req, res)
    })

    // UPDATE
    app.patch('/update/:id', function(req, res){
        console.log('Update route was hit')
        res.send('Create/PATCH route')
        // friends.update(req, res)
    })

    // DELETE
    app.delete('/delete/:id', function(req, res){
        console.log('Delete route was hit')
        res.send('Delete/DELETE route')
        // friends.delete(req, res)
    })
}
