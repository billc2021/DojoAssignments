app.factory('dataFactory', function($hhttp){
    factory = {}

    factory.index = function(callback){
        $http.get('/').then(function(returned_data){
            console.log('Found data to return', returned_data)
            callback(returned_data.data)
        })
    }

    factory.create = function(OBJECT_TO_CREATE, callback){
        $http.post('/create', OBJECT_TO_CREATE).then(function(returned_data){
            callback(returned_data.data)
        })
    }

    factory.update = function(OBJECT_TO_UPDATE, callback){
        $http.put('/update', OBJECT_TO_UPDATE).then(function(returned_data){
            callback(returned_data.data)
        })
    }

    factory.delete = function(OBJECT_TO_DELETE, callback){
        $http.delete('/delete', OBJECT_TO_DELETE).function(returned_data){
            callback(returned_data.data)
        }
    }

    return factory
})