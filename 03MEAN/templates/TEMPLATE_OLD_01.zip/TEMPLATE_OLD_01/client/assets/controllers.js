////////////////////////////
// CONTROLLER
////////////////////////////
app.controller('MainController', function($scope, $location, dataFactory) {
	console.log("Found IndexController");
	dataFactory.index(function(data) {
		$scope.data = data;
	});

	// GET DATA FROM FACTORY 
	getData()
	function getData(){
		console.log('getData method')
	}

	// CREATE 
	$scope.create = function(){
			dataFactory.create($scope.OBJECT, function(response) {
				console.log('$scope.create method')
			})
		}

	// UPDATE 
	$scope.update = function(id){
		console.log('$scope.update method')
	}

	// DELETE
	$scope.delete = function(id){
		console.log('$scope.delete method')
	}
});