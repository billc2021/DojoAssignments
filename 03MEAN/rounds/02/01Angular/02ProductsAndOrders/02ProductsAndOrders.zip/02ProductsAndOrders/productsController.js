require('app')
app.controller('productsController.js', [{
    
}])