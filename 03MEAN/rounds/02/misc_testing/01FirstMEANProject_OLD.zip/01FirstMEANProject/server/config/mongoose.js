// console.log('mongoose.js hit')

// mongoose = require('mongoose')

// console.log('mongoose required, attempting to connect to friendsAPI database...')

// mongoose.connect('mongodb://localhost/friendsAPI')

// console.log('connected to friendsAPI database, attempting to require models/models...')

// require('../models/models')

// console.log('required models/models')

console.log('/server/config/mongoose.js')
var mongoose = require('mongoose')
mongoose.connect('mongodb://localhost/friendsAPI', function(err){
	if (err){ 
		console.log('Error connecting to mongoose', err)
	} else {
		console.log('Connect to Mongoose')
	}
})

require('../models/models')