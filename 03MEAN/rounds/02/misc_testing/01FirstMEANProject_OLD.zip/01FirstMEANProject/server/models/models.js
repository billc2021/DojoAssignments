console.log('/server/models/models.js')
mongoose = require('mongoose')

FriendSchema = mongoose.Schema({
    firstName: String, 
    lastName: String,
    // birthDay: Date
}, {timestamp:true})

mongoose.model('Friend', FriendSchema)