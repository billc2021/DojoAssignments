// mongoose = require('mongoose')
// Friend = mongoose.model('Friend')

// module.exports = {
//     // Index
//     index: function(req, res){
//         Friend.find({}, function(err, all_friends){
//             if(err){
//                 console.log("*********** Finding({}) ERRORS Start ***********");
// 				console.log(err);
// 				console.log("^^^^^^^^^ Finding({}) ERRORS End ^^^^^^^^^")
// 				res.json(err);
//             }else{
//                 res.json(all_friends)
//             }
//         })
//     },

//     // Create
//     create: function(req, res){
//         // console.log("req.body", req.body)
//         var newFriend = new Friend(req.body)
//         console.log('newFriend', newFriend)

//         newFriend.save(function(err, new_friend){
//             if(err){
//                 console.log("*********** Create() ERRORS Start ***********");
// 				console.log(err);
// 				console.log("^^^^^^^^^ Create() ERRORS End ^^^^^^^^^")
// 				res.json(err);
//             }else{
//                 res.json({message: 'Successfully created a new friend', friend: new_friend})
//             }
//         })
//     },
    
//     // Update
//     update: function(req, res){
//         newFriend.findById(req.body._id, function(err, found_friend){
//             if(err){
//                 console.log("*********** FindById() for Update ERRORS Start ***********");
// 				console.log(err);
// 				console.log("^^^^^^^^^ FindById() for Update ERRORS End ^^^^^^^^^")                
//             }else{
//                 found_friend.save(function(err, saved_friend){
//                     if(err){
//                         console.log("*********** Save() for Update ERRORS Start ***********");
//                         console.log(err);
//                         console.log("^^^^^^^^^ Save() for Update ERRORS End ^^^^^^^^^")
//                     }else{
//                         console.log('Friend Saved')
//                         res.json(saved_friend)
//                     }
//                 })
//             }
//         })
//     },

//     // Delete
//     delete: function(req, res){
//         newFriend.fiendByIdAndRemove(req.params._id, function(err, deleted_friend){
//             if(err){
//                 console.log("*********** fiendByIdAndRemove() for Update ERRORS Start ***********");
// 				console.log(err);
// 				console.log("^^^^^^^^^ fiendByIdAndRemove() for Update ERRORS End ^^^^^^^^^") 
//             }else{
//                 response = {
//                     message: 'Friend Successfully Deleted',
//                     id: deleted_friend._id
//                 }   
//             res.send(response)
//             }
//         })
//     }
// }

console.log('/server/controllers/controller.js')

mongoose = require('mongoose')
Friend = mongoose.model('Friend')

module.exports.index = function(req, res){
    Friend.find({}, function(err, friends){
        if(err){
            console.log('Error finding Friends', err)
        }else{
            res.json({ message: 'Friends Index', friends: friends})
        }
    })
}

module.exports.create = function(req, res){
    friend = new Friend({
        firstName: req.body.firstName,
        lastName: req.body.lastName,
    })
    console.log('friend is', friend)

    friend.save(function(err){
        if(err){
            console.log('Error trying to save friend', err)
        }else{
            res.json({ message: 'Successfully created a new friend', friend: friend })
        }
    })
}