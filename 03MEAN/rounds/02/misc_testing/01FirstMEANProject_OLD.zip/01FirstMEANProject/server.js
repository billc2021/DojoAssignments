express = require('express')
bodyParser = require('body-parser')
path = require('path')
mongoose = require('mongoose')

app = express()

app.use(express.static(path.join(__dirname, './client')))
app.use(bodyParser.json())
app.use(bodyParser.urlencoded({extended: true}))

require(path.join(__dirname, './server/models/models.js'))
routes = require('./server/config/routes.js')
routes(app)

app.listen(8000, function(){
    console.log('Running on port 8000')
})
